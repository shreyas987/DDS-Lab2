from django.contrib import admin

# Register your models here.
from .models import customer, productcat, product, order, payment

admin.site.register(customer)
admin.site.register(productcat)
admin.site.register(product)
admin.site.register(order)
admin.site.register(payment)
