from django.shortcuts import render
from django.http import HttpResponse,HttpRequest
from django.template import loader
from django.http import Http404
from django.shortcuts import get_object_or_404, render
from django.shortcuts import redirect
from django.contrib import messages
from .models import customer
from .models import productcat
from .models import product
from .models import payment
from .models import order
import random
import datetime

# Create your views here.
def index(request):
	temp={
		"t1":"Welcome to our shopping site",
		"t2":"",
		"t3":"Enter your Customer ID to start shopping!!",
	}
	user = request.GET.get('userid')
	print(user)
	request.session['username'] = user
	lst = []
	request.session['products'] = lst
	cost=0;
	request.session['totcost'] = cost
	Entry=customer.objects.all()
	if(Entry.filter(customer_id=user)):
		return redirect('http://127.0.0.1:8000/shop/category/',request)
	else:
		 return render(request, 'shoppingsite/index.html', temp) 

	return render(request, 'shoppingsite/index.html', temp)

def category_view(request):
	cat_obj=productcat.objects.all()
	context={
		"object":cat_obj
	}
	
	return render(request, 'shoppingsite/product_cat.html' , context)

def prods_view(request):
	cat=request.GET.get('catid')
	prods=product.objects.all()

	print(request.session['username'])
	prods=prods.filter(category_id=cat)
	if(prods):
		context={
			"products":prods
		}
		return render(request, 'shoppingsite/prods.html' ,context)

def choice_view(request):
	
	prodid=request.GET.get('productid')
	lst = request.session['products']
	lst.append(prodid)
	request.session['products'] = lst
	print(lst)
	val = request.session['totcost']
	prod_obj = product.objects.filter(product_id=prodid)
	for item in prod_obj:
		val=val+item.price
	request.session['totcost'] = val
	print(val)
	##add productid to order table with a new key
	oid=random.randint(10000,99999)
	cus_id=request.session['username']
	cus_id=int(cus_id)
	prodid=int(prodid)
	order_obj = order()
	order_obj.order_id=oid
	order_obj.customer_id=customer.objects.get(customer_id=cus_id)
	order_obj.order_date=datetime.datetime.now()
	order_obj.product_id=product.objects.get(product_id=prodid)
	order_obj.save()
	return render(request, 'shoppingsite/choice.html' , {})

def choice_route_view(request):
	ch = request.GET.get('choiceid')
	if (ch == '1'):
		return redirect('http://127.0.0.1:8000/shop/category/', request)
	##generate orderKey and update it for customerid and orderkey is null in order table

	return render(request, 'shoppingsite/payment.html' , {})

def payment_view(request):
	paychoice=request.GET.get('paymentchoice')
	ord_key=random.randrange(0,9999)
	ord_obj = order.objects.all()
	ord_obj = ord_obj.filter(customer_id=request.session['username'],order_key=0)
	for item in ord_obj:
		item.order_key=ord_key
		item.save()
	pay_obj = payment()
	pay_obj.payment_id = random.randrange(100000,999999)
	pay_obj.payment_mode = paychoice
	pay_obj.order_id = ord_key
	pay_obj.save()
	context={
		"ch":paychoice,
		"paymentid":pay_obj.payment_id,
		"user":request.session['username'],
		"cost":request.session['totcost']
	}
	return render(request, 'shoppingsite/payment_complete.html' ,context)

def payment_complete_view(request):
	return HttpResponse("BYE")
