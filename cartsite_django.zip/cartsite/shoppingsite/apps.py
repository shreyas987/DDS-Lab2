from django.apps import AppConfig


class ShoppingsiteConfig(AppConfig):
    name = 'shoppingsite'
