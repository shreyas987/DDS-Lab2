from django.db import models

# Create your models here.
class customer(models.Model):
	customer_id	=models.BigIntegerField(primary_key='True')
	customer_name	=models.CharField(max_length=30)
	email		=models.CharField(max_length=40)
	phone		=models.BigIntegerField()
	address		=models.CharField(max_length=60)	
	gender		=models.CharField(max_length=1)
	age			=models.IntegerField()

class productcat(models.Model):
	category_id		=models.BigIntegerField(primary_key='True')
	category_name	=models.CharField(max_length=15)

class product(models.Model):
	product_id		=models.BigIntegerField(primary_key='True')
	product_name	=models.CharField(max_length=25)
	price			=models.IntegerField()
	category_id		=models.ForeignKey('Productcat',on_delete=models.CASCADE)
	special_offer	=models.DecimalField(max_digits=2,decimal_places=2)
	quantity		=models.IntegerField()

class order(models.Model):
	order_id	=models.IntegerField(primary_key='True')
	customer_id	=models.ForeignKey('customer',on_delete=models.CASCADE)
	order_date	=models.DateField()
	product_id	=models.ForeignKey('Product',on_delete=models.CASCADE)
	order_key	=models.IntegerField(default=0)

class payment(models.Model):
	payment_id		=models.BigIntegerField(primary_key='True')
	payment_mode	=models.CharField(max_length=10)
	order_id		=models.IntegerField()