from django.urls import path
from . import views

urlpatterns = [
	path('',views.index,name="index"),
	path('category/',views.category_view,name="category_view"),
	path('prods/',views.prods_view,name="prods_view"),
	path('choice/',views.choice_view,name="choice_view"),
	path('choice_route/',views.choice_route_view,name="choice_route_view"),
	path('payment/',views.payment_view,name="payment_view"),
	path('payment_complete/',views.payment_complete_view,name="payment_complete_view"),
] 
